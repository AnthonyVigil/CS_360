package com.example.projecttwo;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class Custom_Items extends BaseAdapter {

    private final Activity context;
    private PopupWindow popup_window;
    ArrayList<Single_Item> items;
    Item_Database database;

    public Custom_Items(Activity context, ArrayList<Single_Item> items, Item_Database db) {
        this.context = context;
        this.items = items;
        this.database = db;
    }

    public static class ViewHolder {
        TextView text_ItemQty;
        TextView text_ItemUnits;
        TextView text_ItemId;
        TextView text_UserEmail;
        TextView text_ItemDesc;
        ImageButton edit_Button;
        ImageButton delete_Button;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;

        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.item_rows, null, true);

            vh.edit_Button = row.findViewById(R.id.Button_Edit);
            vh.text_ItemId = row.findViewById(R.id.textViewItemId);
            vh.text_UserEmail = row.findViewById(R.id.textViewUserEmail);
            vh.text_ItemDesc = row.findViewById(R.id.textView_ItemDescription);
            vh.text_ItemQty = row.findViewById(R.id.textView_ItemQuantity);
            vh.text_ItemUnits = row.findViewById(R.id.textView_Units);
            vh.delete_Button = row.findViewById(R.id.Button_Delete);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        vh.text_ItemId.setText("" + items.get(position).getID());
        vh.text_ItemDesc.setText(items.get(position).getDescription());
        vh.text_ItemQty.setText(items.get(position).getQuantity());
        vh.text_ItemUnits.setText(items.get(position).getUnit());

        // Check is the cell value is zero to change color and send SMS
        String value_item = vh.text_ItemQty.getText().toString().trim();
        if (value_item.equals("0")) {

            // Shows red if value of quantity is zero
            vh.text_ItemQty.setBackgroundColor(Color.RED);
            vh.text_ItemQty.setTextColor(Color.WHITE);
            ItemList.SendSMSMessage(context.getApplicationContext());
        } else {

            // Changes color
            vh.text_ItemQty.setBackgroundColor(Color.parseColor("#E6E6E6"));
            vh.text_ItemQty.setTextColor(Color.BLACK);
        }

        final int positionPopup = position;

        vh.edit_Button.setOnClickListener(view -> editPopup(positionPopup));

        vh.delete_Button.setOnClickListener(view -> {

            database.deleteItem(items.get(positionPopup));
            items = (ArrayList<Single_Item>) database.getAllItems();
            notifyDataSetChanged();
            Toast.makeText(context, "Item Successfully Deleted", Toast.LENGTH_SHORT).show();

            int itemsCount = database.getItemsCount();
            TextView TotalItems = context.findViewById(R.id.textView_TotalItems);
            TotalItems.setText(String.valueOf(itemsCount));
        });

        return  row;
    }

    public Object getItem(int position) { return position;
    }
    public long getItemId(int position) { return position;
    }
    public int getCount() {
        return items.size();
    }

    public void editPopup(final int positionPopup) {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.edit_items, context.findViewById(R.id.Edit_Popup));

        popup_window = new PopupWindow(layout, 1000, 1000, true);
        popup_window.showAtLocation(layout, Gravity.CENTER, 0, 0);

        final EditText editItemDesc = layout.findViewById(R.id.textView_EditText_Description);
        final EditText editItemQty = layout.findViewById(R.id.editText_ItemQuantity);
        final EditText editItemUnit = layout.findViewById(R.id.editText_ItemUnit);

        editItemDesc.setText(items.get(positionPopup).getDescription());
        editItemQty.setText(items.get(positionPopup).getQuantity());
        editItemUnit.setText(items.get(positionPopup).getUnit());

        Button save = layout.findViewById(R.id.edit_ButtonSave);
        Button cancel = layout.findViewById(R.id.edit_ButtonCancel);

        // Click listener for saving item info
        save.setOnClickListener(view -> {
            String itemDesc = editItemDesc.getText().toString();
            String itemQty = editItemQty.getText().toString();
            String itemUnit = editItemUnit.getText().toString();

            Single_Item item = items.get(positionPopup);
            item.setDescription(itemDesc);
            item.setQuantity(itemQty);
            item.setUnit(itemUnit);
            database.updateItem(item);
            items = (ArrayList<Single_Item>) database.getAllItems();
            notifyDataSetChanged();

            Toast.makeText(context, "Item Successfully Updated", Toast.LENGTH_SHORT).show();

            popup_window.dismiss();
        });

        cancel.setOnClickListener(view -> {
            Toast.makeText(context, "Action Cancelled", Toast.LENGTH_SHORT).show();
            popup_window.dismiss();
        });
    }

}
