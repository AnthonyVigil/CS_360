package com.example.projecttwo;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginAct extends AppCompatActivity {

    Boolean EmptyHolder;
    PopupWindow popup_window;
    SQLiteDatabase database;
    User_Database UserBase;
    String Temp_Pass = "NOT_FOUND";
    Activity act;
    Button Login_Button, Register_Button, ForgotPassword_Button;
    EditText UserEmail, UserPassword;
    String NameString, PhoneNumberString, EmailString, PasswordString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_user);
        act = this;

        // Buttons, and saving info
        Login_Button = findViewById(R.id.Button_SignIn);
        Register_Button = findViewById(R.id.Button_Register);
        ForgotPassword_Button = findViewById(R.id.Button_ForgotPassword);
        UserEmail = findViewById(R.id.editText_Username);
        UserPassword = findViewById(R.id.editText_Password);
        UserBase = new User_Database(this);

        // Click listener for login button
        Login_Button.setOnClickListener(view -> {
         // Login
            LoginFunction();
        });

        // Click listener for register button
        Register_Button.setOnClickListener(view -> {

            // Intent to register the user
            Intent intent = new Intent(com.example.projecttwo.LoginAct.this, Register.class);
            startActivity(intent);
        });

        // Click listener for forgot password button
        ForgotPassword_Button.setOnClickListener(view -> {
            EmailString = UserEmail.getText().toString().trim();

            if (!EmailString.isEmpty()) {
                forgotPasswordPopup();
            } else {
                Toast.makeText(com.example.projecttwo.LoginAct.this, "User Email is Empty, Please Revise", Toast.LENGTH_LONG).show();
            }
        });
    }

    // Login function
    public void LoginFunction() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyHolder) {
            // Open user database
            database = UserBase.getWritableDatabase();

            // Searches for user
            Cursor cursor = database.query(User_Database.TABLE_NAME, null, " " + User_Database.COLUMN_3_EMAIL + "=?", new String[]{EmailString}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Stores password and user info
                    Temp_Pass = cursor.getString(cursor.getColumnIndex(User_Database.COLUMN_4_PASSWORD));
                    NameString = cursor.getString(cursor.getColumnIndex(User_Database.COLUMN_1_NAME));
                    PhoneNumberString = cursor.getString(cursor.getColumnIndex(User_Database.COLUMN_2_PHONE_NUMBER));
                    cursor.close();
                }
            }
            UserBase.close();
            CheckFinalResult();
        } else {
            Toast.makeText(com.example.projecttwo.LoginAct.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checks if empty
    public String CheckEditTextNotEmpty() {

        // Gets and stores values
        String message = "";
        EmailString = UserEmail.getText().toString().trim();
        PasswordString = UserPassword.getText().toString().trim();

        // If email box is empty, give message
        // Else, if password is empty, give message
        if (EmailString.isEmpty()) {
            UserEmail.requestFocus();
            EmptyHolder = true;
            message = "User Email is Empty, Please Revise";
        } else if (PasswordString.isEmpty()) {
            UserPassword.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty, Please Revise";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Checks if email and password already exist
    public void CheckFinalResult() {
        if (Temp_Pass.equalsIgnoreCase(PasswordString)) {
            Toast.makeText(com.example.projecttwo.LoginAct.this, "Login Successful", Toast.LENGTH_SHORT).show();

            // Saves name, email and phone number then sends to ItemList
            Bundle bundle = new Bundle();
            bundle.putString("Enter_Username", NameString);
            bundle.putString("User_Email", EmailString);
            bundle.putString("User_PhoneNumber", PhoneNumberString);

            // Intent to navigate to ItemList after login successful
            Intent intent = new Intent(com.example.projecttwo.LoginAct.this, ItemList.class);
            intent.putExtras(bundle);
            startActivity(intent);

            // Close
            EmptyEditTextAfterDataInsert();
        } else {
            // Error message
            Toast.makeText(com.example.projecttwo.LoginAct.this, "Incorrect Email or Password\nor User Not Registered", Toast.LENGTH_LONG).show();
        }
        Temp_Pass = "NOT_FOUND";
    }

    // Empty after login
    public void EmptyEditTextAfterDataInsert() {
        UserEmail.getText().clear();
        UserPassword.getText().clear();
    }

    public void forgotPasswordPopup() {
        LayoutInflater inflater = act.getLayoutInflater();
        View layout = inflater.inflate(R.layout.forgot_password, act.findViewById(R.id.Edit_Popup));

        popup_window = new PopupWindow(layout, 800, 800, true);
        popup_window.showAtLocation(layout, Gravity.CENTER, 0, 0);

        EditText phonenumber = layout.findViewById(R.id.editText_PhoneNumber);
        TextView password = layout.findViewById(R.id.textView_PasswordDisplay);

        // Open database
        database = UserBase.getWritableDatabase();
        Cursor cursor = database.query(User_Database.TABLE_NAME, null, " " + User_Database.COLUMN_3_EMAIL + "=?", new String[]{EmailString}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();

                // Save info
                PhoneNumberString = cursor.getString(cursor.getColumnIndex(User_Database.COLUMN_2_PHONE_NUMBER));
                Temp_Pass = cursor.getString(cursor.getColumnIndex(User_Database.COLUMN_4_PASSWORD));
                cursor.close();
            }
        }
        UserBase.close();

        Button getpass = layout.findViewById(R.id.Button_Get_Pass);
        Button cancelpass = layout.findViewById(R.id.Button_Cancel_Pass);

        // Click listener on get button
        getpass.setOnClickListener(view -> {
            String verifyPhone = phonenumber.getText().toString();

            // If phone number verified, then set the password
            if (verifyPhone.equals(PhoneNumberString)) {
                password.setText(Temp_Pass);
                new android.os.Handler().postDelayed(() -> popup_window.dismiss(), 2000);
            } else {
                Toast.makeText(act, "Phone Number Does Not Match", Toast.LENGTH_LONG).show();
            }
        });

        // Click listener for cancel button
        cancelpass.setOnClickListener(view -> {
            Toast.makeText(act, "Action Cancelled", Toast.LENGTH_SHORT).show();
            popup_window.dismiss();
        });
    }
}
