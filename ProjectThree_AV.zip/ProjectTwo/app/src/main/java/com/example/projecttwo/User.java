package com.example.projecttwo;

public class User {

    int id;
    String UserName;
    String UserPhoneNumber;
    String UserEmailAddress;
    String UserPassword;

    public User() {
        super();
    }

    public User(int i, String Name, String Phone, String Email, String Password) {
        super();
        this.id = i;
        this.UserName = Name;
        this.UserPhoneNumber = Phone;
        this.UserEmailAddress = Email;
        this.UserPassword = Password;
    }

    // Used constructor to set info
    public User(String Name, String Phone, String Email, String Password) {
        this.UserName = Name;
        this.UserPhoneNumber = Phone;
        this.UserEmailAddress = Email;
        this.UserPassword = Password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String name) {
        this.UserName = name;
    }

    public String getUserPhone() {
        return UserPhoneNumber;
    }

    public void setUserPhone(String phone) {
        this.UserPhoneNumber = phone;
    }

    public String getUserEmail() {
        return UserEmailAddress;
    }

    public void setUserEmail(String email) {
        this.UserEmailAddress = email;
    }

    public String getUserPass() {
        return UserPassword;
    }

    public void setUserPass(String pass) {
        this.UserPassword = pass;
    }
}

