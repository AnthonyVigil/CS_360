package com.example.projecttwo;

public class Single_Item {

    String Description;
    String Quantity;
    String Unit;
    String UserEmail;
    int ID;

    public Single_Item() { super();}

    public Single_Item(int i, String Email, String Description, String Quantity, String Unit) {
        super();
        this.ID = i;
        this.UserEmail = Email;
        this.Description = Description;
        this.Quantity = Quantity;
        this.Unit = Unit;
    }

    // Used constructor to set info
    public Single_Item(String Email, String Description, String Quantity, String Unit) {
        this.UserEmail = Email;
        this.Description = Description;
        this.Quantity = Quantity;
        this.Unit = Unit;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getUserEmail() {
        return UserEmail;
    }

    public void setUserEmail(String user_email) {
        this.UserEmail = user_email;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        this.Description = description;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String quantity) {
        this.Quantity = quantity;
    }

    public String getUnit() {
        return Unit;
    }

    public void setUnit(String unit) {
        this.Unit = unit;
    }
}
