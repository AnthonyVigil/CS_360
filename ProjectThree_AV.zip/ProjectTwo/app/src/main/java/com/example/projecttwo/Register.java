package com.example.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {

    SQLiteDatabase database;
    User_Database UserBase;
    String FoundResult = "Not_Found";
    Button Register_Button, Cancel_Button;
    EditText NameText, PhoneNumberText, EmailText, PasswordText;
    Boolean EmptyHolder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_user);

        // Save button and texts
        NameText = findViewById(R.id.editText_Name);
        PhoneNumberText = findViewById(R.id.editText_Number);
        EmailText = findViewById(R.id.editText_Email);
        PasswordText = findViewById(R.id.editText_UserPassword);
        Register_Button = findViewById(R.id.Button_SignUp);
        Cancel_Button = findViewById(R.id.Button_RegisterCancel);
        UserBase = new User_Database(this);

        // Click listener for register button
        Register_Button.setOnClickListener(view -> {
            String message = CheckEditTextIsNotEmpty();

            // If email exist, then use function check email
            // then empty edit function
            if (!EmptyHolder) {
                CheckEmailExists();
                EmptyAfterDataInsertion();
            } else {
                // Shows message
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        // Click listener for cancel button
        Cancel_Button.setOnClickListener(view -> {

            // Intent to ItemList
            startActivity(new Intent(Register.this, SMS.class));
            this.finish();
        });

    }

    // Insert User into the database
    public void InsertUserDatabase(){

        // Set strings with the saved text
        String Name = NameText.getText().toString().trim();
        String Phone = PhoneNumberText.getText().toString().trim();
        String Email = EmailText.getText().toString().trim();
        String Password = PasswordText.getText().toString().trim();

        User user = new User(Name, Phone, Email, Password);
        UserBase.createUser(user);

        // Display message
        Toast.makeText(Register.this,"User Registered Successfully", Toast.LENGTH_LONG).show();

        // Start ItemList
        startActivity(new Intent(Register.this, SMS.class));
        this.finish();
    }

    // Check edit text is not empty
    public String CheckEditTextIsNotEmpty() {

        //Gets values and stores
        String message = "";
        String Name = NameText.getText().toString().trim();
        String Phone = PhoneNumberText.getText().toString().trim();
        String Email = EmailText.getText().toString().trim();
        String Password = PasswordText.getText().toString().trim();

        // If name is empty, print message
        // If phone is empty, print message
        // If email is empty, print message
        // If password is empty, print message
        if (Name.isEmpty()) {
            NameText.requestFocus();
            EmptyHolder = true;
            message = "User Name is Empty, Please Revise";
        } else if (Phone.isEmpty()){
            PhoneNumberText.requestFocus();
            EmptyHolder = true;
            message = "User Phone Number is Empty, Please Revise";
        } else if (Email.isEmpty()){
            EmailText.requestFocus();
            EmptyHolder = true;
            message = "User Email is Empty, Please Revise";
        } else if (Password.isEmpty()){
            PasswordText.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty, Please Revise";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Check if email exists
    public void CheckEmailExists(){
        String Email = EmailText.getText().toString().trim();
        database = UserBase.getWritableDatabase();

        // Search for existing email
        Cursor cursor = database.query(User_Database.TABLE_NAME, null, " " + User_Database.COLUMN_3_EMAIL + "=?", new String[]{Email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();

                // Print message if found
                FoundResult = "Email Found";
                cursor.close();
            }
        }
        UserBase.close();

        // Insert data to user database
        CheckLoginCredentials();
    }

    // Checks for correct login info
    public void CheckLoginCredentials(){

        // Check for existing email
        if(FoundResult.equalsIgnoreCase("Email Found"))
        {
            // Display message
            Toast.makeText(Register.this,"Email Already Exists, Please Use Another",Toast.LENGTH_LONG).show();
        }
        else {

            // If it does not exist then it will insert into database
            InsertUserDatabase();
        }
        // Message
        FoundResult = "Not_Found" ;
    }

    // Empty edit text after data is put into the database
    public void EmptyAfterDataInsertion(){
        NameText.getText().clear();
        PhoneNumberText.getText().clear();
        EmailText.getText().clear();
        PasswordText.getText().clear();
    }

}

