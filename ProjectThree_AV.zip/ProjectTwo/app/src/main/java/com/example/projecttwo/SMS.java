package com.example.projecttwo;


import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class SMS {

    public static AlertDialog doubleButton(final ItemList context){

        // Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        builder.setTitle(R.string.SMS_Title)

                // Yellow Message icon
                .setIcon(R.drawable.sms_notification_image)
                .setCancelable(false)

                // Show message for SMS string
                .setMessage(R.string.SMS_Messsage)

                // When enabled, the message is shown
                .setPositiveButton(R.string.SMS_EnableButton, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Enabled", Toast.LENGTH_LONG).show();
                    ItemList.AllowSendSMS();
                    dialog.cancel();
                })

                // When disabled, message is shown
                .setNegativeButton(R.string.SMS_DisableButton, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Disabled", Toast.LENGTH_LONG).show();
                    ItemList.DenySendSMS();
                    dialog.cancel();
                });

        // Creates builder object and it is returned
        return builder.create();
    }
}
