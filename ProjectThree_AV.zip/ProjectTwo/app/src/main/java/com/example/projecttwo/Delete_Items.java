package com.example.projecttwo;

import androidx.appcompat.app.AlertDialog;

public class Delete_Items {

    public static AlertDialog doubleButton(final ItemList context){

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete all Items")
                .setIcon(R.drawable.delete_items)
                .setCancelable(false)
                .setMessage(R.string.Delete_message)
                .setPositiveButton("Yes", (dialog, arg1) -> {
                    ItemList.YesDeleteItems();
                    dialog.cancel();
                })

                .setNegativeButton("No", (dialog, arg1) -> {
                    ItemList.NoDeleteItems();
                    dialog.cancel();
                });

        return builder.create();
    }


}
