package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;

public class AddItems extends AppCompatActivity {

    String Email_String, Desc_String, Qty_String, Unit_String;
    Button Cancel_Button, AddItem_Button;
    Boolean EmptyCheck;
    Item_Database database;
    TextView User_Email;
    ImageButton Incr_Qty, Decr_Qty;
    EditText ItemDesc_Value, ItemQty_Value, ItemUnit_Value;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_items);

        // Saved buttons, labels and text to variables.
        // Assigned
        // From top to bottom of layout
        User_Email = findViewById(R.id.textView_LoggedUser);
        ItemDesc_Value = findViewById(R.id.editText_ItemDescription);
        ItemUnit_Value = findViewById(R.id.editText_ItemUnit);
        Incr_Qty = findViewById(R.id.Image_IncreaseItem);
        Decr_Qty = findViewById(R.id.Image_DecreaseItem);
        ItemQty_Value = findViewById(R.id.editTextItemQuantity);
        Cancel_Button = findViewById(R.id.Button_AddCancel);
        AddItem_Button = findViewById(R.id.Button_AddItems);
        database = new Item_Database(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Gets UserEmail from ItemList
        Email_String = intent.get().getStringExtra(ItemList.UserEmail);

        // Set user email
        // Uses UserEmail
        User_Email.setText(getString(R.string.User_LoggedIn, Email_String));

        // Added listener for increasing quantity
        Incr_Qty.setOnClickListener(view -> {
            int input = 0, total;
            String value = ItemQty_Value.getText().toString().trim();
            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }
            total = input + 1;
            ItemQty_Value.setText(String.valueOf(total));
        });

        // Added Click listener for decreasing quantity button
        Decr_Qty.setOnClickListener(view -> {
            int input, total;
            String qty = ItemQty_Value.getText().toString().trim();

            if (qty.equals("0")) {
                Toast.makeText(this, "Item Quantity is Zero", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(qty);
                total = input - 1;
                ItemQty_Value.setText(String.valueOf(total));
            }
        });

        // Click listener for cancel button
        Cancel_Button.setOnClickListener(view -> {

            // Returns to ItemList
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        // Added click listener for add item button
        // Sends to itemlist
        AddItem_Button.setOnClickListener(view -> InsertItemIntoDatabase());
    }

    // Puts data into database and sends to Itemlist
    public void InsertItemIntoDatabase() {
        String message = CheckEditTextNotEmpty();

        if (!EmptyCheck) {
            String quantity = Qty_String;
            String unit = Unit_String;
            String email = Email_String;
            String description = Desc_String;

            Single_Item item = new Single_Item(email, description, quantity, unit);
            database.createItem(item);

            // Display toast message after insert in table
            Toast.makeText(this,"Item Added Successfully", Toast.LENGTH_LONG).show();

            // Used to test if Item is correctly inserted into database
//            Toast.makeText(this, item.getDesc().toString(), Toast.LENGTH_LONG).show();
//            Toast.makeText(this, item.getQty().toString(), Toast.LENGTH_LONG).show();
//            Toast.makeText(this, item.getUserEmail().toString(), Toast.LENGTH_LONG).show();
//            Toast.makeText(this, item.getUnit().toString(), Toast.LENGTH_LONG).show();

            // Ends AddItems
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {

            // Displays empty message
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checks for empty box
    public String CheckEditTextNotEmpty() {

        // Saves values
        String message = "";
        Desc_String = ItemDesc_Value.getText().toString().trim();
        Unit_String = ItemUnit_Value.getText().toString().trim();
        Qty_String = ItemQty_Value.getText().toString().trim();

        if (Desc_String.isEmpty()) {
            ItemDesc_Value.requestFocus();
            EmptyCheck = true;
            message = "Item Description is Empty, Please Revise";
        } else if (Unit_String.isEmpty()){
            ItemUnit_Value.requestFocus();
            EmptyCheck = true;
            message = "Item Unit is Empty, Please Revise";
        } else {
            EmptyCheck = false;
        }
        return message;
    }

}
